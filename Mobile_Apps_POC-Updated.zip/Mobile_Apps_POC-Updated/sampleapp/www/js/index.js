/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },

    // deviceready Event Handler
    //
    // Bind any cordova events here. Common events are:
    // 'pause', 'resume', etc.
    onDeviceReady: function() {
        this.receivedEvent('deviceready');
    },

    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
    }
};
function $(obj)
{
	return document.getElementById(obj);
}
function display()
{ 
	if ($("username").value=="root") 
	{ 
			if ($("password").value=="root") 
			{              
				window.location.href = "HomePage.html";
				
			} 
			else 
			{
				alert("Invalid Password")
			}
	} 
	else
	{
		alert("Invalid Username")
	}
}
function reset()
{ 
$("username").value=""
$("password").value=""
	
}

function Welcomereset()
{ 
var elements = document.getElementsByTagName("input")
for (var i = 0; i < elements.length; i++) {
    
	elements[i].value="";
    
}
	
}


function datadisplay()
{ 
	alert("New Service Number # DSN00005")
	if (typeof(Storage) !== "undefined") {
    // Store
	//alert("Functions started")
    localStorage.setItem("SerialNumber ", $("serialnumber").value);
	//alert(localStorage.getItem("SerialNumber "));
	localStorage.setItem("ProblemDescription", $("id_Description").value);
	localStorage.setItem("DealerName", $("id_DealerName").value);
	localStorage.setItem("DealerCode", $("id_DealerCode").value);
	localStorage.setItem("Priority", $("id_Priority").value);
	localStorage.setItem("IssueDate", $("datepicker").value);
	localStorage.setItem("Name", $("id_Name").value);
	localStorage.setItem("EmailId", $("id_EmailId").value);
	localStorage.setItem("MobileNo", $("id_MobileNo").value);
	localStorage.setItem("Attachment", $("id_attachment").value);
		
    // Retrieve
    //document.getElementById("result").innerHTML = localStorage.getItem("serialnumber");
	//alert(localStorage.getItem("SerialNumber "),localStorage.getItem("ProblemDescription "));
	
} else {
    document.getElementById("result").innerHTML = "Sorry, your browser does not support Web Storage...";
}

window.location.href = "HomePage.html";


}
function $$(obj)
{
	return localStorage.getItem(obj);
}


function Ticket()
{
alert("Submitted Successfully");
window.location.href = "TicketHistory.html";


}

/*function Onload()
{

document.getElementById("serialnumber").value=$$("SerialNumber");
document.getElementById("id_Description").value=$$("ProblemDescription");
document.getElementById("id_DealerName").innerHTML=$$("DealerName"); 
document.getElementById("id_DealerCode").innerHTML=$$("DealerCode"); 
document.getElementById("id_Priority").innerHTML=$$("Priority");     
document.getElementById("datepicker").innerHTML=$$("IssueDate");      
document.getElementById("id_Name").innerHTML=$$("Name");              
document.getElementById("id_EmailId").innerHTML=$$("EmailId");        
document.getElementById("id_MobileNo").innerHTML=$$("MobileNo");      
document.getElementById("Attachment").innerHTML=$$("Attachment");     
                                                                      
}
*/

 function addText() 
	{
        var Alltext = "";
		
		Alltext += document.getElementById("newText").value
		document.getElementById("alltext").value = Alltext+document.getElementById("alltext").value;
		document.getElementById("newText").value=""
		window.alert("Successfully updated");
		
    
	
	
}

function cancel()
{
 var retVal = confirm("Do you want to continue ?");
               if( retVal == true ){
                  window.location.href = "HomePage.html";
                  return true;
               }
               else{
                  return false;
               }


}


app.initialize();

